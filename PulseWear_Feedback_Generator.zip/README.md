# PulseWear Feedback Generator

Generate 500 realistic user feedback items for product management analysis.

## Requirements

- **Python 3.7+** — [Download here](https://www.python.org/downloads/)
  - During installation, check **"Add Python to PATH"**
- No other dependencies — uses only the Python standard library

---

## Running on Windows

### Option 1: Double-click
Right-click `generate_pulsewear_feedback.py` → **Open with → Python**

### Option 2: Command Prompt
```cmd
cd C:\path\to\this\folder
python generate_pulsewear_feedback.py
```

### Option 3: VS Code
Open the file and click the **▶ Play** button in the top-right corner,
or right-click in the editor → **Run Python File in Terminal**.

The script will print progress and write `pulsewear_feedback_data.csv` when done.

---

## Customization

Open `generate_pulsewear_feedback.py` and edit the parameters at the top:

**Line 21 — Number of items:**
```python
num_feedback_items = 1000  # change from 500
```

**Line 54 — Output filename:**
```python
output_filename = "my_feedback.csv"
```

**Line 49 — Date range:**
```python
feedback_start_date = datetime.now() - timedelta(days=365)  # past year
```

**Lines 24–29 — Channel mix** (must sum to 1.0):
```python
channel_distribution = {
    "App Review": 0.35,
    "Support Ticket": 0.25,
    "Social Media": 0.25,
    "Beta Testing": 0.15
}
```

Save (`Ctrl + S`) and run again to regenerate.

---

## Output Format

| Column | Description | Example |
|--------|-------------|---------|
| feedback_id | Unique ID | FB00123 |
| user_id | User identifier | user_45678 |
| timestamp | Date/time | 2026-02-15 14:30:22 |
| channel | Source | App Review, Support Ticket |
| platform | Specific platform | iOS App Store, Twitter |
| category | Type | Bug Report, Feature Request |
| topic | Theme | battery, ui_ux, sleep_tracking |
| feedback_text | The feedback | "Battery life is terrible..." |
| sentiment_score | 1–5 rating | 2 (negative) |
| word_count | Text length | 12 |
| priority_score | 1–10 importance | 7 |
| status | Processing status | New, Reviewed, Resolved |

---

## Troubleshooting

### "Python is not recognized"
Reinstall Python from [python.org](https://www.python.org/downloads/) and check **"Add Python to PATH"**, then restart Command Prompt.

### No CSV file appears
Check the same folder as the script. Look for error messages in the terminal.

---

## What This Generates

Realistic feedback for a fictional smart fitness device company (PulseWear Labs):
- App reviews (iOS & Android)
- Customer support tickets
- Social media mentions (Twitter, Facebook, Instagram, Reddit)
- Beta testing feedback

Includes 15% vague/noise comments for realistic signal-to-noise ratio.

---

*Fictional company — for educational and demonstration purposes only.*
