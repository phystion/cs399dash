"""
Generate 500 synthetic user feedback responses for PulseWear Labs
This script creates realistic feedback from multiple channels (app reviews, support tickets,
social media, beta testing) for a smart fitness device and companion app company.
"""

import csv
import random
import statistics
from collections import Counter
from datetime import datetime, timedelta

# No third-party dependencies required — uses only the Python standard library

# ============================================================================
# CONFIGURATION PARAMETERS - Adjust these as needed
# ============================================================================

# Total number of feedback items to generate
num_feedback_items = 500

# Distribution of feedback across channels (should sum to 1.0)
channel_distribution = {
    "App Review": 0.35,      # 35% from app store reviews
    "Support Ticket": 0.25,  # 25% from customer support
    "Social Media": 0.25,    # 25% from Twitter, Facebook, etc.
    "Beta Testing": 0.15     # 15% from beta testing program
}

# Distribution of feedback categories
category_distribution = {
    "Feature Request": 0.30,
    "Bug Report": 0.25,
    "General Complaint": 0.20,
    "Praise": 0.15,
    "Question": 0.10
}

# Sentiment distribution (1-5 scale)
sentiment_weights = {
    1: 0.15,  # Very negative
    2: 0.25,  # Negative
    3: 0.25,  # Neutral
    4: 0.20,  # Positive
    5: 0.15   # Very positive
}

# Date range for feedback (past 6 months)
feedback_start_date = datetime.now() - timedelta(days=180)
feedback_end_date = datetime.now()

# Output filename
output_filename = "pulsewear_feedback_data.csv"

# ============================================================================
# FEEDBACK CONTENT TEMPLATES
# ============================================================================

random.seed(42)

# Feature request templates by topic
feature_requests = {
    "sleep_tracking": [
        "Would love to see sleep quality tracking with REM cycle analysis",
        "Please add sleep tracking! My old device had this and I miss it",
        "Sleep monitoring would be amazing. Can you add it?",
        "I want detailed sleep analytics with recommendations",
        "Add sleep stages tracking like deep sleep and light sleep"
    ],
    "social_features": [
        "Can we get a feature to challenge friends to fitness competitions?",
        "Social sharing is too limited. I want to share workouts with my running club",
        "Need better integration with social media platforms",
        "Let me compete with friends in step challenges",
        "Add a community feature where users can share workout tips"
    ],
    "battery": [
        "Battery life is good but could be better. Maybe add a power saving mode?",
        "Extend battery life please, I have to charge every 2 days",
        "Low power mode would be great for long hikes",
        "Battery optimization needed - drains too fast with GPS on"
    ],
    "workout_types": [
        "Add yoga workout tracking!",
        "Need swimming workout support with pool length tracking",
        "Please add rock climbing as a workout type",
        "Can you add HIIT workout presets?",
        "Missing dance workout tracking",
        "Add support for weight training with rep counting"
    ],
    "notifications": [
        "More customizable notification options please",
        "Let me choose which apps can send notifications to my device",
        "Notification filtering is needed - too many spam alerts",
        "Add smart notifications that learn my preferences"
    ],
    "ui_ux": [
        "The app interface is confusing. Needs a redesign",
        "Make the dashboard more customizable",
        "Dark mode for the app would be perfect",
        "Improve the navigation, too many clicks to get to workout history",
        "Add widgets for home screen"
    ],
    "metrics": [
        "Add VO2 max tracking",
        "Heart rate variability (HRV) would be awesome",
        "Please include stress level monitoring",
        "Blood oxygen tracking missing",
        "Add calorie burn accuracy improvements"
    ],
    "integrations": [
        "Strava integration please!",
        "Need better sync with Apple Health",
        "Google Fit integration not working properly",
        "MyFitnessPal connection would be great",
        "Spotify control from the device screen"
    ]
}

# Bug report templates
bug_reports = [
    "App crashes when I try to view workout history from last month",
    "GPS tracking is way off, shows me running through buildings",
    "Heart rate monitor stops working mid-workout randomly",
    "Sync between device and app fails constantly",
    "Battery percentage stuck at 50% and won't update",
    "Notifications don't vibrate anymore after latest update",
    "Step counter seems inaccurate, counts steps while driving",
    "Can't export workout data to CSV, export button doesn't work",
    "Sleep tracking doesn't record anything, shows blank screen",
    "Device freezes on the clock face and needs restart",
    "Bluetooth connection drops every 10 minutes",
    "Water resistance rating seems wrong, device got wet and stopped working",
    "Screen doesn't turn on when I raise my wrist",
    "Workout auto-pause doesn't work when I stop running",
    "Calorie calculation seems way too high",
    "Device doesn't charge, charging icon doesn't appear",
    "Touch screen not responsive in certain areas",
    "App login fails with 'invalid credentials' even with correct password",
    "Historical data disappeared after app update",
    "Heart rate zones are calculated incorrectly"
]

# General complaints
complaints = [
    "This device is overpriced for what it offers",
    "Battery life is terrible compared to competitors",
    "The wristband is uncomfortable and causes skin irritation",
    "Customer support takes forever to respond",
    "App is slow and laggy on older phones",
    "Too many features locked behind premium subscription",
    "Device looks cheap and plasticky",
    "Screen is too small to read notifications",
    "Not enough watch faces to choose from",
    "Setup process is overly complicated",
    "App drains my phone battery",
    "Workout detection doesn't work automatically",
    "Can't use device without creating an account, privacy concern",
    "Updates break features that were working fine",
    "No way to contact support directly from the app"
]

# Praise comments
praise = [
    "Love this device! Best fitness tracker I've owned",
    "The app interface is clean and intuitive",
    "Heart rate monitoring is super accurate",
    "Great value for money, highly recommend",
    "Customer support was very helpful when I had an issue",
    "Battery lasts longer than advertised!",
    "GPS tracking is spot-on during my runs",
    "The sleep insights have helped me improve my sleep quality",
    "Comfortable to wear all day and night",
    "Love the automatic workout detection feature",
    "Syncs perfectly with my phone every time",
    "Water resistance is legit, wore it swimming with no issues",
    "Step counter is very accurate",
    "The workout summaries are detailed and useful",
    "Perfect size, not too bulky like other trackers"
]

# Questions
questions = [
    "How do I reset my device to factory settings?",
    "Is the device waterproof or just water resistant?",
    "Can I replace the wristband with a third-party one?",
    "What's the difference between active minutes and steps?",
    "How accurate is the calorie tracking?",
    "Can I use this without a smartphone?",
    "Does this track swimming workouts?",
    "How do I calibrate the heart rate sensor?",
    "Is there a warranty on this device?",
    "Can multiple users share one device?",
    "How long does the battery typically last?",
    "What heart rate zones does the device use?",
    "Can I get notifications from all apps?",
    "How do I update the firmware?",
    "Is my health data stored securely?"
]

# Vague/unhelpful comments (noise in the data)
vague_comments = [
    "Not great",
    "Could be better",
    "Meh",
    "It's okay I guess",
    "Works fine",
    "Pretty good",
    "Nothing special",
    "Average product",
    "It does what it says",
    "Not impressed",
    "Decent",
    "Fine for the price",
    "I don't know, it's alright"
]

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def random_date(start_date, end_date):
    """Generate a random datetime between start_date and end_date"""
    time_between = end_date - start_date
    days_between = time_between.days
    random_days = random.randrange(days_between)
    random_seconds = random.randrange(24 * 60 * 60)
    return start_date + timedelta(days=random_days, seconds=random_seconds)

def generate_feature_request():
    """Generate a feature request comment"""
    topic = random.choice(list(feature_requests.keys()))
    base_comment = random.choice(feature_requests[topic])

    # Sometimes add context or urgency
    if random.random() < 0.3:
        urgency = random.choice([
            " This is a must-have!",
            " Really need this feature.",
            " Hope this gets prioritized.",
            " Surprised this isn't already included.",
            " This would make the product perfect."
        ])
        base_comment += urgency

    return base_comment, topic

def generate_bug_report():
    """Generate a bug report comment"""
    base_comment = random.choice(bug_reports)

    # Sometimes add device/app version info or frustration
    if random.random() < 0.4:
        addition = random.choice([
            " This started after the latest update.",
            " Very frustrating!",
            " Please fix this ASAP.",
            " This is making the device unusable.",
            " Happens every single time.",
            " Running on iOS 17, app version 2.3.1"
        ])
        base_comment += addition

    return base_comment

def generate_complaint():
    """Generate a general complaint"""
    base_comment = random.choice(complaints)

    # Sometimes add comparison to competitors
    if random.random() < 0.25:
        comparison = random.choice([
            " My Fitbit was better.",
            " Garmin handles this way better.",
            " Apple Watch doesn't have this problem.",
            " Other brands do this better."
        ])
        base_comment += comparison

    return base_comment

def generate_praise():
    """Generate praise comment"""
    base_comment = random.choice(praise)

    # Sometimes add recommendation
    if random.random() < 0.3:
        recommendation = random.choice([
            " Would definitely recommend to friends!",
            " Already told my gym buddies about it.",
            " 5 stars from me!",
            " Worth every penny.",
            " Exceeded my expectations."
        ])
        base_comment += recommendation

    return base_comment

def generate_question():
    """Generate a question"""
    return random.choice(questions)

def generate_vague():
    """Generate a vague comment (noise)"""
    return random.choice(vague_comments)

def get_sentiment_for_category(category):
    """Determine sentiment score based on category with appropriate distribution"""
    if category == "Praise":
        return random.choices([4, 5], weights=[0.3, 0.7])[0]
    elif category == "Bug Report":
        return random.choices([1, 2, 3], weights=[0.5, 0.4, 0.1])[0]
    elif category == "General Complaint":
        return random.choices([1, 2], weights=[0.6, 0.4])[0]
    elif category == "Feature Request":
        return random.choices([2, 3, 4], weights=[0.2, 0.5, 0.3])[0]
    elif category == "Question":
        return 3  # Neutral
    else:
        # Default to overall sentiment distribution
        return random.choices(
            list(sentiment_weights.keys()),
            weights=list(sentiment_weights.values())
        )[0]

FIRST_NAMES = [
    "james", "john", "robert", "michael", "william", "david", "richard", "joseph",
    "thomas", "charles", "mary", "patricia", "jennifer", "linda", "barbara",
    "elizabeth", "susan", "jessica", "sarah", "karen"
]

def generate_user_id():
    """Generate a realistic user identifier"""
    formats = [
        lambda: f"user_{random.randint(10000, 99999)}",
        lambda: f"{random.choice(FIRST_NAMES)}_{random.randint(100, 9999)}",
        lambda: f"{random.choice(FIRST_NAMES)}{random.randint(10, 999)}",
        lambda: f"beta_tester_{random.randint(100, 9999)}"
    ]
    return random.choice(formats)()

# ============================================================================
# MAIN GENERATION LOGIC
# ============================================================================

def generate_feedback_data():
    """Generate the complete feedback dataset"""

    print(f"Generating {num_feedback_items} feedback items for PulseWear Labs...")

    feedback_data = []

    for i in range(num_feedback_items):
        # Determine channel
        channel = random.choices(
            list(channel_distribution.keys()),
            weights=list(channel_distribution.values())
        )[0]

        # Determine category
        category = random.choices(
            list(category_distribution.keys()),
            weights=list(category_distribution.values())
        )[0]

        # Generate feedback text based on category
        # 15% chance of vague/unhelpful comment (noise in data)
        if random.random() < 0.15:
            feedback_text = generate_vague()
            category = "Vague"
            topic = "General"
        elif category == "Feature Request":
            feedback_text, topic = generate_feature_request()
        elif category == "Bug Report":
            feedback_text = generate_bug_report()
            topic = "Technical"
        elif category == "General Complaint":
            feedback_text = generate_complaint()
            topic = "General"
        elif category == "Praise":
            feedback_text = generate_praise()
            topic = "General"
        elif category == "Question":
            feedback_text = generate_question()
            topic = "Support"
        else:
            feedback_text = "No comment provided"
            topic = "General"

        # Generate other fields
        feedback_id = f"FB{str(i+1).zfill(5)}"
        user_id = generate_user_id()
        timestamp = random_date(feedback_start_date, feedback_end_date)
        sentiment = get_sentiment_for_category(category)

        # Platform distribution based on channel
        if channel == "App Review":
            platform = random.choices(
                ["iOS App Store", "Google Play Store"],
                weights=[0.55, 0.45]
            )[0]
        elif channel == "Social Media":
            platform = random.choices(
                ["Twitter", "Facebook", "Instagram", "Reddit"],
                weights=[0.4, 0.3, 0.15, 0.15]
            )[0]
        else:
            platform = channel

        # Word count (rough estimate)
        word_count = len(feedback_text.split())

        # Priority score (would be assigned by ML model or product manager)
        # Higher for bugs and feature requests, lower for vague comments
        if category in ["Bug Report", "Feature Request"]:
            priority_base = random.randint(5, 10)
        elif category == "Vague":
            priority_base = random.randint(1, 3)
        else:
            priority_base = random.randint(3, 7)

        # Add some randomness
        priority = max(1, min(10, priority_base + random.randint(-2, 2)))

        # Status (most are new, some are reviewed or resolved)
        status = random.choices(
            ["New", "Reviewed", "In Progress", "Resolved", "Closed"],
            weights=[0.50, 0.20, 0.10, 0.15, 0.05]
        )[0]

        # Create feedback record
        feedback_record = {
            "feedback_id": feedback_id,
            "user_id": user_id,
            "timestamp": timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            "channel": channel,
            "platform": platform,
            "category": category,
            "topic": topic,
            "feedback_text": feedback_text,
            "sentiment_score": sentiment,
            "word_count": word_count,
            "priority_score": priority,
            "status": status
        }

        feedback_data.append(feedback_record)

        # Progress indicator
        if (i + 1) % 100 == 0:
            print(f"  Generated {i + 1}/{num_feedback_items} items...")

    return feedback_data

# ============================================================================
# EXECUTE AND SAVE
# ============================================================================

if __name__ == "__main__":
    # Generate the data
    feedback_list = generate_feedback_data()

    # Sort by timestamp (most recent first)
    feedback_list.sort(key=lambda r: r["timestamp"], reverse=True)

    # Save to CSV
    with open(output_filename, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=feedback_list[0].keys())
        writer.writeheader()
        writer.writerows(feedback_list)

    print(f"\n✓ Successfully generated {len(feedback_list)} feedback items")
    print(f"✓ Data saved to: {output_filename}")

    # Print summary statistics
    print("\n" + "="*70)
    print("SUMMARY STATISTICS")
    print("="*70)

    def print_counts(counter):
        for val, cnt in counter.most_common():
            print(f"{val}    {cnt}")

    print("\nFeedback by Channel:")
    print_counts(Counter(r["channel"] for r in feedback_list))

    print("\nFeedback by Category:")
    print_counts(Counter(r["category"] for r in feedback_list))

    print("\nFeedback by Status:")
    print_counts(Counter(r["status"] for r in feedback_list))

    print("\nSentiment Distribution:")
    sent_counts = Counter(r["sentiment_score"] for r in feedback_list)
    for k in sorted(sent_counts):
        print(f"{k}    {sent_counts[k]}")

    print("\nPriority Score Statistics:")
    priorities = [r["priority_score"] for r in feedback_list]
    n = len(priorities)
    mn = min(priorities)
    mx = max(priorities)
    mean = statistics.mean(priorities)
    std = statistics.stdev(priorities)
    sorted_p = sorted(priorities)
    q1 = sorted_p[n // 4]
    med = statistics.median(priorities)
    q3 = sorted_p[(3 * n) // 4]
    print(f"count    {n}\nmean     {mean:.6f}\nstd      {std:.6f}\nmin      {mn}\n25%      {q1}\n50%      {med}\n75%      {q3}\nmax      {mx}")

    print("\n" + "="*70)
    print("Sample of generated feedback:")
    print("="*70)
    fields = ["feedback_id", "channel", "category", "feedback_text"]
    for rec in feedback_list[:10]:
        row = "  ".join(str(rec[f])[:40] for f in fields)
        print(row)

    print("\n✓ Generation complete!")
